import streamlit as st
import pandas as pd
from datetime import datetime, time
import google.generativeai as genai

# Security: Load API key from secrets.toml
try:
    api_key = st.secrets["google_api_key"]["GOOGLE_API_KEY"]
except KeyError:
    st.error("GOOGLE_API_KEY not found in secrets.toml. Please follow setup instructions.")
    st.stop()

# Configure Google Gemini AI
genai.configure(api_key=api_key)

# Initialize AI Model (ensure this matches your enabled Google Cloud API)
model = genai.GenerativeModel("gemini-1.5-pro-latest")

# Doctor data with availability
doctors = {
    'Dr. John Doe': {
        'specialty': 'Cardiologist',
        'available_times': [time(9,0), time(14,0)]
    },
    'Dr. Jane Smith': {
        'specialty': 'Dermatologist',
        'available_times': [time(10,0), time(15,0)]
    },
    'Dr. Emily White': {
        'specialty': 'Neurologist',
        'available_times': [time(11,0), time(16,0)]
    }
}

# Session state for appointments
if 'appointments' not in st.session_state:
    st.session_state['appointments'] = []

def book_appointment(patient_name, doctor, date, time_input):
    # Validate time selection
    if time_input not in doctors[doctor]['available_times']:
        st.error(f"{doctor} is only available at: {', '.join([t.strftime('%H:%M') for t in doctors[doctor]['available_times']])}")
        return

    # Create appointment record
    appointment = {
        'Patient': patient_name.strip(),
        'Doctor': doctor,
        'Specialty': doctors[doctor]['specialty'],
        'Date': date.strftime("%Y-%m-%d"),
        'Time': time_input.strftime("%H:%M")
    }
    
    st.session_state['appointments'].append(appointment)
    st.success(f"Appointment confirmed with {doctor} on {date} at {time_input}")

def get_ai_response(query):
    try:
        response = model.generate_content(query)
        return response.text.strip()
    except Exception as e:
        return f"Medical AI response error: {str(e)}"

# Streamlit UI
st.title("🩺 AI Health Assistant & Appointment Scheduler")

tab1, tab2 = st.tabs(["AI Consultation", "Book Appointment"])

with tab1:
    st.subheader("Medical Q&A")
    user_question = st.text_input("Enter your health-related question:")
    
    if st.button("Ask AI"):
        if user_question.strip():
            response = get_ai_response(user_question)
            st.markdown(f"**AI Response:**\n\n{response}")
        else:
            st.warning("Please enter a question")

with tab2:
    st.subheader("Schedule an Appointment")
    with st.form("appointment_form"):
        patient = st.text_input("Full Name")
        selected_doctor = st.selectbox("Choose Physician", list(doctors.keys()))
        appointment_date = st.date_input("Date", min_value=datetime.today())
        appointment_time = st.time_input("Time", value=time(9,0))
        
        st.caption("Office hours: 9:00-12:00 & 14:00-17:00")
        st.caption("All times shown in your local time zone")

        submitted = st.form_submit_button("Schedule")
        
        if submitted:
            if not patient.strip():
                st.error("Patient name is required")
            else:
                book_appointment(
                    patient_name=patient,
                    doctor=selected_doctor,
                    date=appointment_date,
                    time_input=appointment_time
                )

    # Display appointments
    if st.session_state['appointments']:
        st.subheader("Your Appointments")
        df = pd.DataFrame(st.session_state['appointments'])
        st.table(df.style.format({
            'Date': lambda x: pd.to_datetime(x).strftime('%Y-%m-%d'),
            'Time': lambda x: pd.to_datetime(x).strftime('%I:%M %p')
        }))
    else:
        st.info("No upcoming appointments")